//
//  Workout.swift
//  workoutApp
//
//  Created by Özlem Şerifoğulları on 22.05.2023.
//

import SwiftUI

struct Workout: Hashable, Identifiable {
    let id = UUID()
    let imageName : String
    let title: String
    let description: String
}

struct WorkoutList {
    
    static let workoutTypes = [
        
        Workout(imageName: "plank", title: "Plank", description: "Get into a face down position on the floor supporting your upper body on your forearms. Your elbows should be bent at 90 degrees. Extend your legs straight out behind you, supporting them on your toes and balls of your feet. Keep your body in a straight line by tightening your abdominal and oblique muscles. Hold for as long as possible."),
        Workout(imageName: "squats", title: "Squats", description: "Place your feet at shoulder width apart while keeping your chest up and your abdominals braced. Begin the movement by swinging your arms up towards your shoulders. At the same time, bend at the knees and drive your hips back like you’re sitting in a chair. Once your upper thighs are parallel with the ground, pause, then drive your hips forward to return to the starting position."),
        Workout(imageName: "lunges", title: "Lunges", description: "Stand straight with your feet shoulder width apart and place your hands on your hips. This is the start position. Step forward with either leg in a long stride. Keep your other foot in place behind you. Bend your knees as you do this so your body is lowered towards the ground. Keep your back straight throughout the movement. Continue down until your front knee is just above the ground. (Your front leg should be bent 90 degrees at the knee) Hold for a count of one. Push down through your front heel and extend both knees to return to the start position. Pause then repeat with your other leg. When you have lunged with both legs, that is one repetition. Repeat"),
        Workout(imageName: "dumbbellRows", title: "Dumbbell Rows", description: "Place a dumbbell on each side of a flat bench. Place your right knee on the end of the bench. Bend your torso from the waist until your upper body is parallel to the floor, while placing your right hand on the bench in front of you for support. With your left hand, pick up the dumbbell with an overhand grip. The palm of your hand should be facing into you. Keep your lower back straight. This is the start position. At the top of the movement, hold for a count of one and squeeze your back muscles. Return to the start position inhaling as you do so. Repeat. Complete all repetitions for one side before switching sides."),
        Workout(imageName: "overheadDumbbellPress", title: "Overhead Dumbbell Press", description: "Sit on a military press bench or bench that has a back support, holding a dumbbell in each hand with an overhand grip. Place the dumbbells on top of your thighs with your palms facing down. Raise the dumbbells to your shoulders. Rotate your wrists so that the palms of your hands are facing away from you. This is the start position. As you exhale, push the dumbbells up and over your head by extending your arms until the dumbbells touch at the top of the movement. Pause for a count of one. Slowly return to the start position inhaling as you do so. Repeat."),
        Workout(imageName: "pushups", title: "Pushups", description: "Get into position by placing your hands flat on the floor, directly below your shoulders. Extend your legs out behind you, with only your toes and balls of your feet touching the floor. Hold your body up and keep your back straight by tightening your abdominal muscles. Your neck and head should be bent slightly back. Lower your chest towards the ground by bending your elbows until your chest is just above the ground or you feel a stretching of your chest and shoulders. Hold for a count of one. Press upwards from your chest and shoulders, straightening your arms as you return to the starting position. Hold for a count of one. Repeat."),
        Workout(imageName: "sidePlank", title: "Side Plank", description: "Lie on your side on an exercise mat. Fully extend your legs with one resting on top of the other. Fully extend the top arm down the side of your body. Bend the arm at floor level to 90 degrees. Your upper arm should be parallel to your body, while your forearm is at 90 degrees. This is the start position. Lift your body off the ground and balance on your forearm and the side of your foot, while keeping your body in a straight line. Contract your abdominal muscles and relax your shoulders. Continue breathing throughout the whole exercise. Hold this position for as long as you can. Relax and change sides. Repeat."),
        Workout(imageName: "singleLegDeadlift", title: "Single Leg Deadlift", description: "Stand tall with a tight core while holding a pair of dumbbells. Keeping your chest up and your gaze straight ahead, shift all of your bodyweight to your left foot. Bend the right knee, allowing the right foot to lift off the ground. Maintaining a flat back, tilt your upper body forward. Do not allow the dumbbells to pull you down. Control your descent. Simultaneously, allow the right foot to counterbalance the shift in weight. Feel the contraction in your hamstrings and pause once your upper body is parallel with the ground. Slowly return to the starting position."),
        Workout(imageName: "resistanceBandBicepCurl", title: "Resistance Band Bicep Curl", description: "Begin the movement by stepping on to a resistance band with your feet at shoulder-width, toes pointed slightly out. Holding the handles of the band in each hand, tighten your abdominals and straighten your lower back. Keep your chest up and gaze forward. Using an underhand grip or hammer fist grip, slowly pull the band towards your shoulders. Keep your upper arm in place, moving only your forearms. Once you reach the top of the movement, pause, and slowly lower the band to the starting position. Do not lock out your elbows.")
    
    ]
}
