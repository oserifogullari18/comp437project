//
//  workoutAppApp.swift
//  workoutApp
//
//  Created by Özlem Şerifoğulları on 22.05.2023.
//

import SwiftUI

@main
struct workoutAppApp: App {
    var body: some Scene {
        WindowGroup {
            WorkoutListView()
        }
    }
}
