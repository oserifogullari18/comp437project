//
//  WorkoutDetailView.swift
//  workoutApp
//
//  Created by Özlem Şerifoğulları on 22.05.2023.
//

import SwiftUI

struct WorkoutDetailView: View {
    
    var workout: Workout
 
    var body: some View {

            VStack {
                    Image(workout.imageName)
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: 400, height: 300)
                    Text(workout.title)
                        .font(.system(size: 80))
                        .bold()
                        .padding(.bottom)
                    Text(workout.description)
                        .font(.system(size: 20))
                        .padding(.horizontal)
                    
                    Spacer()
                    
                    Button(action: {
                        
                    }) {
                        Text("Start to Practice")
                            .font(.system(size: 25))
                            .foregroundColor(.white)
                    }
                    .buttonStyle(.borderless)
                    .frame(width: 200, height: 50)
                    .background(.red)
                    .cornerRadius(10)

                }
            .frame(width: 1080, height: 700)
        
    }
}

struct WorkoutDetailView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutDetailView(workout: WorkoutList.workoutTypes.first!)
    }
}

struct HelloWorldView: View{
    var body: some View{
        Text("Hello World")
    }
}
