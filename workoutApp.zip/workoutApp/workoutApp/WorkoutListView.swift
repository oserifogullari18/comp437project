//
//  WorkoutListView.swift
//  workoutApp
//
//  Created by Özlem Şerifoğulları on 22.05.2023.
//

import SwiftUI

struct Option: Hashable{
    let title: String
    let imageName: String
    let id: Int
}

struct WorkoutListView: View {
    
    
    @State var currentOption = 0
    let options: [Option] = [
        .init(title: "Home", imageName: "house", id: 0),
        .init(title: "Trainings", imageName: "dumbbell",
              id: 1),
        .init(title: "Backgrounds",
              imageName: "person.and.background.dotted",
              id: 2),
        .init(title: "Agenda", imageName: "calendar",
              id: 3),
        .init(title: "Profile", imageName: "person.crop.circle",
              id: 4)
    ]
    
    var workouts: [Workout] = WorkoutList.workoutTypes
    @State var isWorkoutSelected : Bool = false
    @State var selectedWorkout: Workout?
    
    var body: some View {
        NavigationView {
            VStack{
                let current = options[currentOption]
                ForEach(options, id: \.self) { option in
                    HStack{
                        Image(systemName: option.imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30)
                        Text(option.title)
                            .frame(minWidth: 100)
                            .foregroundColor(current == option ? Color.blue : Color.black)
                    }
                    .padding()
                    .onTapGesture {
                        currentOption = option.id
                    }
                    
                    
                }
            }
                        
            switch currentOption {
            case 0:
                MainView(isWorkoutSelected: $isWorkoutSelected, selectedWorkout: $selectedWorkout )
                if(isWorkoutSelected == true){
                    WorkoutDetailView(workout: selectedWorkout!)
                }
            case 1:
                Text("Trainings view")
            case 2:
                Text("Backgrounds view")
            case 3:
                Text("Agenda View")
            case 4:
                Text("Profile view")
            default:
                MainView(isWorkoutSelected: $isWorkoutSelected, selectedWorkout: $selectedWorkout)
                if(isWorkoutSelected == true){
                    WorkoutDetailView(workout: selectedWorkout!)
                }
            }
        }
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutListView()
    }
}

struct WeekView: View {
    var body: some View {
        HStack {
            VStack(alignment: .center){
                Text("Mon")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
                
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Tue")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Wed")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Thu")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Fri")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Sat")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
            
            VStack(alignment: .center){
                Text("Sun")
                    .font(.system(size: 50))
                    .padding(2)
                Image(systemName: "checkmark.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 30, height: 30)
            }
            .frame(width: 120, height: 80)
        }
        .frame(width: 1080, height: 100)
        .padding(.bottom, 50)
    }
}

struct MainView: View{
    @Binding var isWorkoutSelected : Bool
    var workouts: [Workout] = WorkoutList.workoutTypes
    @Binding var selectedWorkout: Workout?
    
    var body: some View{
        ScrollView {
            VStack (alignment: .leading ) {
                Text("Welcome Özlem!")
                    .font(.system(size: 60))
                        
                WeekView()
                
                HStack{
                    Text("Workouts")
                        .frame(width: 60, alignment: .leading)
                    NavigationLink("View All"){
                        Text("Why it looks like that?")
                    }
                    .buttonStyle(.borderless)
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(workouts) { workout in
                            VStack(alignment: .center, spacing: 3) {
                                Image(workout.imageName)
                                    .resizable()
                                    .aspectRatio( contentMode: .fill)
                                    .frame(width: 270, height: 200)
                                Text(workout.title)
                                    .lineLimit(2)
                                    .font(.system(size: 20))
                                    .bold()
                            }
                            .padding()
                            .onTapGesture {
                                selectedWorkout = workout
                                isWorkoutSelected = true
                                print(selectedWorkout as Any)
                            }
                        }
                    }
                    Spacer()
                }
                        
            }
        }
    }
}


