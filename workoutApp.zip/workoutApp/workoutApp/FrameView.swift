//
//  FrameView.swift
//  workoutApp
//
//  Created by Özlem Şerifoğulları on 13.06.2023.
//

import SwiftUI

struct FrameView: View {
    var image: CGImage?
    var label = Text("frame")
    
    var body: some View {
        if let image = image{
            Image(image, scale: 1.0, orientation: .up, label: label)
            
        }else{
            Color.black
        }
    }
}

struct FrameView_Previews: PreviewProvider {
    static var previews: some View {
        FrameView()
    }
}
